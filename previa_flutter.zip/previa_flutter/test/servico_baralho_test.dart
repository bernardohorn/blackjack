import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:blackjack_inicial/servico_baralho.dart';

void main() {
  test('Cria seis baralhos e compra quatro cartas com o mesmo ID', () async {
    final enderecos = <Uri>[];
    final servico = ServicoBaralho(
      cliente: MockClient((endereco) async {
        enderecos.add(endereco.url);
        final criar = endereco.url.path.contains('/new/');
        return http.Response(
          jsonEncode({
            'success': true,
            'deck_id': 'mesa_teste',
            'remaining': criar ? 312 : 308,
            if (!criar)
              'cards': List.generate(
                4,
                (_) => {'value': '10', 'suit': 'HEARTS', 'image': ''},
              ),
          }),
          200,
        );
      }),
    );
    addTearDown(servico.fechar);

    await servico.criarBaralho();
    final cartas = await servico.comprarCartas(4);
    expect(enderecos[0].queryParameters['deck_count'], '6');
    expect(enderecos[1].path, '/api/deck/mesa_teste/draw/');
    expect(enderecos[1].queryParameters['count'], '4');
    expect(cartas.length, 4);
    expect(servico.cartasRestantes, 308);
  });

  test('Compra incompleta não altera a contagem local', () async {
    final servico = ServicoBaralho(
      cliente: MockClient(
        (_) async => http.Response(
          jsonEncode({
            'success': true,
            'deck_id': 'mesa_teste',
            'remaining': 308,
            'cards': [
              {'value': '10', 'suit': 'HEARTS'},
            ],
          }),
          200,
        ),
      ),
    );
    addTearDown(servico.fechar);
    servico.idBaralho = 'mesa_teste';
    servico.cartasRestantes = 312;

    await expectLater(servico.comprarCartas(4), throwsFormatException);
    expect(servico.cartasRestantes, 312);
  });

  test('Resposta de outro baralho é rejeitada', () async {
    final servico = ServicoBaralho(
      cliente: MockClient(
        (_) async => http.Response(
          jsonEncode({
            'success': true,
            'deck_id': 'outro_id',
            'remaining': 311,
            'cards': [
              {'value': '10', 'suit': 'HEARTS'},
            ],
          }),
          200,
        ),
      ),
    );
    addTearDown(servico.fechar);
    servico.idBaralho = 'mesa_teste';
    servico.cartasRestantes = 312;
    await expectLater(servico.comprarCartas(1), throwsFormatException);
  });

  test('Erro HTTP é informado sem repetir a compra', () async {
    int chamadas = 0;
    final servico = ServicoBaralho(
      cliente: MockClient((_) async {
        chamadas++;
        return http.Response('Indisponível', 503);
      }),
    );
    addTearDown(servico.fechar);
    servico.idBaralho = 'mesa_teste';
    servico.cartasRestantes = 312;
    await expectLater(servico.comprarCartas(1), throwsException);
    expect(chamadas, 1);
  });
}
