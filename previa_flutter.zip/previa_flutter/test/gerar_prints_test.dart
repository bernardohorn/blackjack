// Este arquivo é uma ferramenta de entrega. Não faz parte do código do app.
// Gera prints da interface Flutter com respostas simuladas e reproduzíveis.
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:blackjack_inicial/main.dart';
import 'package:blackjack_inicial/servico_baralho.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

const gerarPrints = bool.fromEnvironment('GERAR_PRINTS');

// As imagens ficam vazias para usar o desenho local da carta, sem internet.
ServicoBaralho servicoSimulado(List<List<String>> compras) {
  int proximaCompra = 0;
  int restantes = 312;
  return ServicoBaralho(
    cliente: MockClient((pedido) async {
      final criar = pedido.url.path.contains('/new/');
      if (!criar && proximaCompra >= compras.length) {
        return http.Response(
          'Falha simulada para demonstrar a recuperação.',
          503,
        );
      }
      final valores = criar ? <String>[] : compras[proximaCompra++];
      restantes -= valores.length;
      return http.Response(
        jsonEncode({
          'success': true,
          'deck_id': 'mesa_dos_prints',
          'remaining': restantes,
          if (!criar)
            'cards': [
              for (int indice = 0; indice < valores.length; indice++)
                {
                  'value': valores[indice],
                  'suit': indice.isEven ? 'SPADES' : 'HEARTS',
                  'image': '',
                },
            ],
        }),
        200,
      );
    }),
  );
}

// O teste normal usa uma fonte especial para comparar pixels.
// Para prints legíveis, carregamos o Roboto que já vem no SDK do Flutter.
Future<void> carregarFontesDoSdk() async {
  final configuracao = File('.dart_tool/package_config.json').absolute;
  final dados = jsonDecode(await configuracao.readAsString());
  final pacote = (dados['packages'] as List).firstWhere(
    (item) => item['name'] == 'flutter',
  );
  final raiz = configuracao.uri.resolve('${pacote['rootUri']}/');
  final fontes = FontLoader('Roboto');
  for (final nome in [
    'roboto-regular.ttf',
    'roboto-medium.ttf',
    'roboto-bold.ttf',
  ]) {
    final arquivo = File.fromUri(
      raiz.resolve('../../bin/cache/artifacts/material_fonts/$nome'),
    );
    fontes.addFont(arquivo.readAsBytes().then(ByteData.sublistView));
  }
  await fontes.load();

  final icones = FontLoader('MaterialIcons');
  final arquivoIcones = File.fromUri(
    raiz.resolve(
      '../../bin/cache/artifacts/material_fonts/materialicons-regular.otf',
    ),
  );
  icones.addFont(arquivoIcones.readAsBytes().then(ByteData.sublistView));
  await icones.load();

  // O Roboto não inclui todos os naipes. Usamos uma fonte do sistema
  // apenas na captura; nenhum arquivo de fonte do sistema é distribuído.
  final fontesSimbolos = [
    '${Platform.environment['WINDIR'] ?? 'C:/Windows'}/Fonts/seguisym.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/truetype/noto/NotoSansSymbols-Regular.ttf',
  ];
  final arquivoSimbolos = fontesSimbolos
      .map(File.new)
      .firstWhere((arquivo) => arquivo.existsSync());
  final simbolos = FontLoader('Simbolos');
  simbolos.addFont(arquivoSimbolos.readAsBytes().then(ByteData.sublistView));
  await simbolos.load();
}

Future<GlobalKey> prepararTela(
  WidgetTester teste,
  ServicoBaralho servico, {
  double altura = 960,
}) async {
  teste.view.devicePixelRatio = 1;
  teste.view.physicalSize = Size(390, altura);
  addTearDown(teste.view.resetPhysicalSize);
  addTearDown(teste.view.resetDevicePixelRatio);
  final chave = GlobalKey();
  await teste.pumpWidget(
    RepaintBoundary(
      key: chave,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          colorSchemeSeed: Colors.amber,
          scaffoldBackgroundColor: const Color(0xFF103B2C),
          fontFamily: 'Roboto',
          fontFamilyFallback: const ['Simbolos'],
        ),
        home: TelaJogo(servico: servico),
      ),
    ),
  );
  await teste.pumpAndSettle();
  return chave;
}

Future<void> salvarPrint(
  WidgetTester teste,
  GlobalKey chave,
  String nome,
) async {
  expect(teste.takeException(), isNull);
  await teste.runAsync(() async {
    final area =
        chave.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final imagem = await area.toImage(pixelRatio: 2);
    final dados = await imagem.toByteData(format: ui.ImageByteFormat.png);
    final pasta = Directory('docs/prints');
    await pasta.create(recursive: true);
    await File(
      '${pasta.path}/$nome.png',
    ).writeAsBytes(dados!.buffer.asUint8List());
    imagem.dispose();
  });
}

Future<void> iniciarJogo(WidgetTester teste) async {
  await teste.tap(find.text('Iniciar jogo'));
  await teste.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    if (gerarPrints) await carregarFontesDoSdk();
  });

  testWidgets('Print do menu', (teste) async {
    final chave = await prepararTela(teste, servicoSimulado([]));
    await salvarPrint(teste, chave, '01-menu');
  }, skip: !gerarPrints);

  testWidgets('Print completo das regras', (teste) async {
    final chave = await prepararTela(teste, servicoSimulado([]));
    await teste.tap(find.text('Regras'));
    await teste.pumpAndSettle();
    await salvarPrint(teste, chave, '02-regras');
  }, skip: !gerarPrints);

  testWidgets('Print da mesa com carta escondida', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['9', 'ACE', '7', '6'],
      ]),
    );
    await iniciarJogo(teste);
    expect(find.text('Jogador · 16 pontos'), findsOneWidget);
    expect(find.text('Banca · 11 pontos + ?'), findsOneWidget);
    await salvarPrint(teste, chave, '03-mesa');
  }, skip: !gerarPrints);

  testWidgets('Print de vitória', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['10', '10', '8', '7'],
      ]),
    );
    await iniciarJogo(teste);
    await teste.tap(find.text('Parar'));
    await teste.pumpAndSettle();
    expect(find.text('Você venceu!'), findsOneWidget);
    await salvarPrint(teste, chave, '04-vitoria');
  }, skip: !gerarPrints);

  testWidgets('Print de derrota por estouro', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['KING', '9', '8', '8'],
        ['7'],
      ]),
    );
    await iniciarJogo(teste);
    await teste.tap(find.text('Pedir carta'));
    await teste.pumpAndSettle();
    expect(find.text('Jogador · 25 pontos'), findsOneWidget);
    await salvarPrint(teste, chave, '05-derrota');
  }, skip: !gerarPrints);

  testWidgets('Print de empate', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['10', '10', '8', '8'],
      ]),
    );
    await iniciarJogo(teste);
    await teste.tap(find.text('Parar'));
    await teste.pumpAndSettle();
    expect(find.text('Empate!'), findsOneWidget);
    await salvarPrint(teste, chave, '06-empate');
  }, skip: !gerarPrints);

  testWidgets('Print de Blackjack', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['ACE', '10', 'KING', '7'],
      ]),
    );
    await iniciarJogo(teste);
    expect(find.text('Blackjack! Você venceu.'), findsOneWidget);
    await salvarPrint(teste, chave, '07-blackjack');
  }, skip: !gerarPrints);

  testWidgets('Print de falha sem alterar o placar', (teste) async {
    final chave = await prepararTela(
      teste,
      servicoSimulado([
        ['9', 'ACE', '7', '6'],
      ]),
    );
    await iniciarJogo(teste);
    await teste.tap(find.text('Pedir carta'));
    await teste.pumpAndSettle();
    expect(find.text('Vitórias: 0 · Derrotas: 0 · Empates: 0'), findsOneWidget);
    expect(find.text('Iniciar jogo'), findsOneWidget);
    await salvarPrint(teste, chave, '08-falha');
  }, skip: !gerarPrints);
}
