import 'package:flutter_test/flutter_test.dart';
import 'package:blackjack_inicial/carta.dart';

// Nos testes, não precisamos baixar imagens nem usar a internet.
Carta carta(String valor) => Carta(valor: valor, naipe: 'SPADES', imagem: '');

void main() {
  test('J, Q e K valem dez pontos', () {
    expect(calcularPontos([carta('JACK'), carta('QUEEN'), carta('KING')]), 30);
  });

  test('Ás vale onze quando isso não estoura', () {
    expect(calcularPontos([carta('ACE'), carta('6')]), 17);
  });

  test('Ás vira um para evitar o estouro', () {
    expect(calcularPontos([carta('9'), carta('7'), carta('ACE')]), 17);
  });

  test('Vários ases são ajustados um por vez', () {
    expect(calcularPontos([carta('ACE'), carta('ACE'), carta('9')]), 21);
    expect(calcularPontos([carta('ACE'), carta('ACE'), carta('KING')]), 12);
  });

  test('Blackjack exige exatamente duas cartas', () {
    expect(temBlackjack([carta('ACE'), carta('KING')]), isTrue);
    expect(temBlackjack([carta('7'), carta('7'), carta('7')]), isFalse);
  });

  test('Uma mão pode estourar mesmo depois do ajuste do Ás', () {
    expect(
      calcularPontos([carta('ACE'), carta('KING'), carta('KING'), carta('2')]),
      23,
    );
  });
}
