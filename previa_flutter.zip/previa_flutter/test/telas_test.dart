import 'dart:async';
import 'dart:convert';

import 'package:blackjack_inicial/main.dart';
import 'package:blackjack_inicial/servico_baralho.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

// MockClient responde sem internet. As mãos seguem a ordem de distribuição:
// jogador, banca, jogador, banca. Imagem vazia usa a carta local da tela.
Map<String, String> cartaJson(String valor) {
  return {'value': valor, 'suit': 'HEARTS', 'image': ''};
}

http.Response respostaCartas(List<String> valores, int restantes) {
  return http.Response(
    jsonEncode({
      'success': true,
      'deck_id': 'mesa_teste',
      'remaining': restantes,
      'cards': valores.map(cartaJson).toList(),
    }),
    200,
  );
}

http.Response respostaBaralho() {
  return http.Response(
    jsonEncode({'success': true, 'deck_id': 'mesa_teste', 'remaining': 312}),
    200,
  );
}

ServicoBaralho servicoSimulado(
  List<List<String>> compras, {
  List<Uri>? enderecos,
  bool falharNaSegundaCompra = false,
}) {
  int indiceCompra = 0;
  int restantes = 312;
  return ServicoBaralho(
    cliente: MockClient((pedido) async {
      enderecos?.add(pedido.url);
      if (pedido.url.path.contains('/new/')) return respostaBaralho();
      if (falharNaSegundaCompra && indiceCompra == 1) {
        return http.Response('Indisponível', 503);
      }
      final valores = compras[indiceCompra++];
      restantes -= valores.length;
      return respostaCartas(valores, restantes);
    }),
  );
}

Future<void> tocar(WidgetTester teste, String texto) async {
  final botao = find.text(texto);
  await teste.ensureVisible(botao);
  await teste.tap(botao);
  await teste.pumpAndSettle();
}

Future<void> abrirJogo(WidgetTester teste, ServicoBaralho servico) async {
  await teste.pumpWidget(MaterialApp(home: TelaJogo(servico: servico)));
  await tocar(teste, 'Iniciar jogo');
}

void main() {
  testWidgets('Blackjack conta uma vitória e cada nova rodada conta uma vez', (
    teste,
  ) async {
    final enderecos = <Uri>[];
    await abrirJogo(
      teste,
      servicoSimulado([
        ['ACE', '9', 'KING', '8'],
        ['ACE', '9', 'KING', '8'],
      ], enderecos: enderecos),
    );
    expect(find.text('Blackjack! Você venceu.'), findsOneWidget);
    expect(find.text('Vitórias: 1 · Derrotas: 0 · Empates: 0'), findsOneWidget);

    await tocar(teste, 'Nova rodada');
    expect(find.text('Vitórias: 2 · Derrotas: 0 · Empates: 0'), findsOneWidget);
    expect(enderecos.length, 3); // Uma criação e duas distribuições.
  });

  testWidgets('Blackjack das duas mãos conta somente um empate', (teste) async {
    await abrirJogo(
      teste,
      servicoSimulado([
        ['ACE', 'ACE', 'KING', 'KING'],
      ]),
    );
    expect(find.text('Empate! Os dois fizeram Blackjack.'), findsOneWidget);
    expect(find.text('Vitórias: 0 · Derrotas: 0 · Empates: 1'), findsOneWidget);
  });

  testWidgets('Blackjack da banca conta somente uma derrota', (teste) async {
    await abrirJogo(
      teste,
      servicoSimulado([
        ['10', 'ACE', '9', 'KING'],
      ]),
    );
    expect(find.text('A banca fez Blackjack e venceu.'), findsOneWidget);
    expect(find.text('Vitórias: 0 · Derrotas: 1 · Empates: 0'), findsOneWidget);
  });

  testWidgets('Estouro do jogador encerra a rodada e conta uma derrota', (
    teste,
  ) async {
    final enderecos = <Uri>[];
    await abrirJogo(
      teste,
      servicoSimulado([
        ['10', '10', '8', '7'],
        ['5'],
      ], enderecos: enderecos),
    );
    await tocar(teste, 'Pedir carta');
    expect(find.text('Você estourou 21. A banca venceu.'), findsOneWidget);
    expect(find.text('Vitórias: 0 · Derrotas: 1 · Empates: 0'), findsOneWidget);
    expect(enderecos.length, 3); // A banca não compra após o estouro.
  });

  testWidgets('Falha de compra não conta derrota nem repete a chamada', (
    teste,
  ) async {
    final enderecos = <Uri>[];
    await abrirJogo(
      teste,
      servicoSimulado(
        [
          ['10', '10', '8', '7'],
        ],
        enderecos: enderecos,
        falharNaSegundaCompra: true,
      ),
    );
    await tocar(teste, 'Pedir carta');
    expect(find.textContaining('Não foi possível concluir.'), findsOneWidget);
    expect(find.text('Vitórias: 0 · Derrotas: 0 · Empates: 0'), findsOneWidget);
    expect(enderecos.length, 3);
    expect(
      teste
          .widget<FilledButton>(
            find.widgetWithText(FilledButton, 'Pedir carta'),
          )
          .onPressed,
      isNull,
    );
  });

  testWidgets('Menu e regras preservam mão, placar e baralho ao continuar', (
    teste,
  ) async {
    final enderecos = <Uri>[];
    await abrirJogo(
      teste,
      servicoSimulado([
        ['10', '10', '8', '7'],
      ], enderecos: enderecos),
    );
    expect(find.text('Jogador · 18 pontos'), findsOneWidget);
    expect(find.text('Banca · 10 pontos + ?'), findsOneWidget);
    await teste.tap(find.byTooltip('Voltar ao menu'));
    await teste.pumpAndSettle();
    expect(find.text('Continuar mesa'), findsOneWidget);

    await tocar(teste, 'Regras');
    expect(find.text('Regras do jogo'), findsOneWidget);
    await teste.pageBack();
    await teste.pumpAndSettle();
    await tocar(teste, 'Continuar mesa');
    expect(find.text('Jogador · 18 pontos'), findsOneWidget);
    expect(find.text('Banca · 10 pontos + ?'), findsOneWidget);
    expect(
      enderecos.length,
      2,
    ); // Continuar e abrir regras não consultam a API.

    await tocar(teste, 'Parar');
    expect(find.text('Vitórias: 1 · Derrotas: 0 · Empates: 0'), findsOneWidget);
    await teste.tap(find.byTooltip('Voltar ao menu'));
    await teste.pumpAndSettle();
    await tocar(teste, 'Continuar mesa');
    expect(find.text('Vitórias: 1 · Derrotas: 0 · Empates: 0'), findsOneWidget);
    expect(enderecos.length, 2);
  });

  testWidgets('Menu e ações ficam bloqueados enquanto uma compra responde', (
    teste,
  ) async {
    final compraPendente = Completer<http.Response>();
    int chamadas = 0;
    final servico = ServicoBaralho(
      cliente: MockClient((pedido) async {
        chamadas++;
        if (pedido.url.path.contains('/new/')) return respostaBaralho();
        if (pedido.url.queryParameters['count'] == '4') {
          return respostaCartas(['10', '9', '8', '7'], 308);
        }
        return compraPendente.future;
      }),
    );
    await abrirJogo(teste, servico);
    await teste.ensureVisible(find.text('Pedir carta'));
    await teste.tap(find.text('Pedir carta'));
    await teste.tap(find.text('Pedir carta'));
    await teste.pump();
    expect(chamadas, 3);
    expect(
      teste
          .widget<IconButton>(
            find.byWidgetPredicate(
              (widget) =>
                  widget is IconButton && widget.tooltip == 'Voltar ao menu',
            ),
          )
          .onPressed,
      isNull,
    );
    expect(
      teste
          .widget<OutlinedButton>(find.widgetWithText(OutlinedButton, 'Parar'))
          .onPressed,
      isNull,
    );

    compraPendente.complete(respostaCartas(['2'], 307));
    await teste.pumpAndSettle();
    expect(find.text('Jogador · 20 pontos'), findsOneWidget);
    expect(find.text('Vitórias: 0 · Derrotas: 0 · Empates: 0'), findsOneWidget);
  });
}
