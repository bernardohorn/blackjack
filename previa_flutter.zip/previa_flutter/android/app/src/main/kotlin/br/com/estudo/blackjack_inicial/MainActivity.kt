package br.com.estudo.blackjack_inicial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
