# Lista de pendências

## Essenciais para a entrega

- [x] Executar e registrar `flutter analyze`, `flutter test` e a compilação web da versão final: análise sem problemas, 17 testes funcionais aprovados e build web concluído.
- [x] Capturar e conferir menu, regras, mesa em andamento, vitória, derrota, empate, Blackjack e falha em `docs/prints/`: oito testes de captura aprovados e oito imagens conferidas visualmente.
- [x] Incluir o índice das capturas no README e documentar as respostas simuladas em [docs/PRINTS.md](docs/PRINTS.md).
- [x] Confirmar uma rodada no navegador com a Deck of Cards API real e conferir o carregamento das imagens, a compra de cartas, o resultado e o placar.
- [ ] Executar em aparelho ou emulador Android e conferir navegação, cartas, botões e textos.
- [ ] Definir o repositório de destino, publicar o código documentado no GitHub e registrar o link de entrega.

O repositório Git local está criado na branch `main`. Isso ainda não representa publicação no GitHub.

## Melhorias opcionais

- [ ] Aproximar cores, espaçamento e disposição das telas do design do Figma, se isso fizer parte da próxima etapa.
- [ ] Avaliar o salvamento do placar entre sessões. Hoje ele vale apenas enquanto o aplicativo está aberto.

Os itens opcionais não fazem parte da implementação prometida para esta prévia. Não há necessidade de acrescentar apostas, contas de usuário ou outras regras para concluir esta entrega.
