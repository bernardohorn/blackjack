# Blackjack 21 — prévia em Flutter

Projeto simples para estudar Flutter e explicar um jogo de Blackjack. O aplicativo tem menu inicial, tela de regras e mesa de jogo. O placar registra vitórias, derrotas e empates durante a sessão. Os nomes e comentários que criamos estão em português do Brasil.

## Como executar

É necessário ter o Flutter instalado, com Dart compatível com `^3.12.2`, e um navegador ou dispositivo Android configurado. Abra esta pasta no VS Code ou Android Studio e execute:

```powershell
cd C:\blackjack\previa_flutter
flutter pub get
flutter run -d chrome
```

Para Android, conecte um celular com depuração USB ou abra um emulador. Use `flutter devices` para conferir os dispositivos e `flutter run -d ID_DO_DISPOSITIVO` para escolher um. A permissão de internet está no projeto. O jogo precisa de internet para obter as cartas da API.

## O que ler primeiro

| Ordem | Arquivo | O que entender |
| --- | --- | --- |
| 1 | [lib/carta.dart](lib/carta.dart) | Representação da carta, pontuação e identificação de Blackjack. |
| 2 | [lib/servico_baralho.dart](lib/servico_baralho.dart) | As duas chamadas à API e a conferência das respostas. |
| 3 | [lib/main.dart](lib/main.dart) | Menu, estado da partida, placar e ações dos botões. |
| 4 | [lib/tela_regras.dart](lib/tela_regras.dart) | Tela de explicação das regras, sem chamadas à API. |

As pastas `android` e `web` contêm a estrutura gerada pelo Flutter para essas plataformas. Para apresentar a lógica do projeto, concentrem-se nos quatro arquivos de `lib`.

## Caminho de uma rodada

No **menu inicial**, toque em **Iniciar jogo** ou consulte **Regras**. Depois de começar, o botão do menu passa a ser **Continuar mesa**: retornar à mesa preserva a rodada e não compra cartas novamente. Fechar ou recarregar o aplicativo inicia uma sessão nova: não há salvamento permanente.

1. **Iniciar jogo** abre a mesa e chama `iniciarRodada`. Ela cria seis baralhos e compra quatro cartas.
2. As cartas são distribuídas alternadamente: jogador, banca, jogador, banca. A segunda carta da banca fica escondida.
3. **Pedir carta** chama `pedirCarta`, que compra uma carta e soma os pontos. Acima de 21, o jogador perde. Com 21, a banca joga automaticamente.
4. **Parar** chama `parar` e depois `jogarBanca`. A banca revela a carta e compra enquanto tiver menos de 17 pontos.
5. O aplicativo compara as pontuações, mostra vitória, derrota ou empate e atualiza o placar da sessão.
6. **Nova rodada** usa o mesmo baralho. Quando restam 78 cartas ou menos, criamos um novo conjunto de seis baralhos antes da distribuição.

Blackjack significa **21 com exatamente duas cartas**. Logo após a distribuição, conferimos se o jogador, a banca ou ambos fizeram Blackjack.

Se ambas as mãos têm Blackjack, há empate; se apenas uma tem, ela vence. Não há apostas, divisão de mãos ou compra dobrada nesta prévia.

## Seis conceitos do código

- **Variável:** guarda uma informação. `carregando` indica se estamos esperando a API.
- **Lista:** guarda vários itens. `cartasJogador` reúne as cartas do jogador.
- **Classe:** reúne informações ou ações relacionadas. `Carta` tem valor, naipe e imagem.
- **Future / async / await:** uma chamada à internet leva tempo. `await` aguarda a resposta sem travar a interface.
- **setState:** avisa ao Flutter que os dados mudaram e que a tela precisa ser reconstruída.
- **JSON:** formato da resposta da API. `jsonDecode` converte esse texto em dados que o Dart pode ler.

`bool` é verdadeiro ou falso; `int` é um número inteiro; `String` é texto; `void` indica que uma função não devolve um valor. Um nome começando com `_` é privado no Dart. `mounted` verifica se a tela ainda existe depois de uma espera.

Os nomes do Flutter, as palavras da linguagem Dart e as chaves do JSON precisam manter sua escrita original. Por exemplo: `StatefulWidget`, `build`, `setState`, `if`, `return`, `deck_id` e `remaining`. Nossos nomes, como `pedirCarta` e `cartasRestantes`, estão em português.

### Menu, navegação e placar no código

- **`enum ResultadoRodada`:** define três resultados possíveis: `vitoria`, `derrota` e `empate`. Ao terminar uma rodada, esse resultado indica qual contador do placar deve aumentar.
- **`Navigator.push`:** abre a tela de regras por cima da tela atual. Ao voltar, a partida continua com as mesmas cartas.
- **`initState`:** executa uma vez quando o estado da tela é criado. Aqui ele prepara o serviço de cartas; nos testes, recebe um serviço com respostas simuladas.

Menu e mesa compartilham o mesmo estado. `mostrarMenu` muda qual conteúdo aparece, enquanto as mãos e o placar permanecem guardados.

## As duas chamadas à API

Base: `https://deckofcardsapi.com`.

| Ação | Endpoint GET | Explicação |
| --- | --- | --- |
| Criar baralhos | `/api/deck/new/shuffle/?deck_count=6` | Recebe o ID do conjunto e 312 cartas restantes. |
| Comprar cartas | `/api/deck/{deck_id}/draw/?count=4` | Retira quatro cartas na distribuição. Nas próximas compras, usamos `count=1`. |

`deck_id` identifica o baralho, `cards` contém as cartas e `remaining` informa quantas sobraram. **A API entrega cartas; as regras e a pontuação ficam no aplicativo.** Não existe chamada própria para “parar” ou “vencer”.

Mesmo usando GET, uma compra retira cartas do baralho remoto. Por isso, se uma compra falhar, encerramos a rodada e o próximo início cria uma nova mesa. Não repetimos a compra automaticamente, porque a API pode já ter retirado as cartas. Uma falha não conta como derrota no placar.

## Como explicar o Ás

Primeiro somamos cada Ás como 11. Se o total passar de 21, reduzimos 10 pontos para transformar um Ás em 1. Repetimos isso enquanto for necessário e houver ases para ajustar.

Exemplo: **9 + 7 + Ás = 27 → 17**. O Ás passa a valer 1.

## O que esta prévia inclui

Menu inicial, tela de regras e mesa com cartas da API, pontuação, carta escondida da banca, resultados, placar da sessão e nova rodada. A banca para em 17, inclusive quando tem um Ás valendo 11. Durante as chamadas, os botões ficam bloqueados. Se uma imagem falhar, o valor e o naipe continuam visíveis.

As pendências essenciais e as melhorias opcionais estão em [PENDENCIAS.md](PENDENCIAS.md).

## Verificações

```powershell
flutter analyze
flutter test
flutter build web --no-pub --no-web-resources-cdn
```

A pasta `test` verifica as regras e o tratamento das respostas da API. Os testes usam respostas simuladas e não dependem da internet. Executar os testes não comprova o funcionamento da API real ou a execução em Android.

Nesta entrega, `flutter analyze` terminou sem problemas, os **17 testes funcionais passaram** e a compilação web concluiu com sucesso. Os oito testes de captura ficam pulados na execução normal; quando ativados separadamente, os **oito passaram** e geraram as imagens conferidas visualmente.

Também foi verificada uma rodada no navegador com a API real: seis baralhos deram 312 cartas, a distribuição deixou 308 e uma compra deixou 307. O jogador começou com 5 + J = 15, pediu 7 e estourou com 22; o placar registrou uma derrota. As imagens reais das cartas carregaram. A execução em Android ainda não foi verificada.

## Capturas de tela e entrega

As oito capturas estão em `docs/prints/`. Consulte a [galeria e a explicação dos prints](docs/PRINTS.md).

| Tela ou estado | Captura |
| --- | --- |
| Menu inicial | [01-menu.png](docs/prints/01-menu.png) |
| Regras do jogo | [02-regras.png](docs/prints/02-regras.png) |
| Mesa em andamento | [03-mesa.png](docs/prints/03-mesa.png) |
| Vitória | [04-vitoria.png](docs/prints/04-vitoria.png) |
| Derrota | [05-derrota.png](docs/prints/05-derrota.png) |
| Empate | [06-empate.png](docs/prints/06-empate.png) |
| Blackjack | [07-blackjack.png](docs/prints/07-blackjack.png) |
| Falha de comunicação | [08-falha.png](docs/prints/08-falha.png) |

São capturas dos widgets reais do aplicativo Flutter, com respostas da API simuladas para reproduzir cada estado. As cartas usam o desenho local de valor e naipe. Para gerar novamente:

```powershell
flutter test test/gerar_prints_test.dart --dart-define=GERAR_PRINTS=true
```

Esta pasta reúne o código-fonte e a documentação para entrega, versionados localmente na branch `main`. A publicação no GitHub aguarda o repositório de destino e o envio; o link será registrado quando estiver disponível.

Fontes: [documentação da Deck of Cards API](https://deckofcardsapi.com/) e [pacote HTTP do Dart](https://pub.dev/packages/http).
