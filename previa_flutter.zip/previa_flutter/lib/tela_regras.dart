import 'package:flutter/material.dart';

// Esta tela só apresenta texto: não guarda estado nem consulta a API.
class TelaRegras extends StatelessWidget {
  const TelaRegras({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Regras do jogo')),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Text(
          'OBJETIVO\n'
          'Ter mais pontos que a banca sem ultrapassar 21.\n\n'
          'VALOR DAS CARTAS\n'
          '2 a 10 valem o número da carta. J, Q e K valem 10. '
          'O Ás vale 11 ou 1, conforme o que evita estourar.\n\n'
          'SUAS AÇÕES\n'
          'Pedir carta acrescenta uma carta à sua mão. '
          'Parar encerra sua vez e revela a carta fechada da banca. '
          'Ao chegar a 21, sua vez termina automaticamente.\n\n'
          'A BANCA\n'
          'Compra enquanto tem menos de 17. Para com 17 ou mais, '
          'inclusive quando um Ás vale 11.\n\n'
          'RESULTADO\n'
          'Blackjack é 21 com as duas primeiras cartas. '
          'Se os dois tiverem Blackjack, há empate. '
          'Se você passar de 21, perde. Se a banca passar de 21, você vence. '
          'Nos demais casos, vence a maior pontuação; valores iguais empatam.\n\n'
          'ESTA PRÉVIA\n'
          'Usa seis baralhos e não tem apostas. '
          'A API fornece as cartas; o aplicativo calcula os pontos e o resultado. '
          'Falhas de conexão não contam no placar.',
          style: TextStyle(fontSize: 17, height: 1.5),
        ),
      ),
    );
  }
}
