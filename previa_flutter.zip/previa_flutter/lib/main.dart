import 'package:flutter/material.dart';

import 'carta.dart';
import 'servico_baralho.dart';
import 'tela_regras.dart';

// O enum limita o resultado às três possibilidades de uma rodada concluída.
enum ResultadoRodada { vitoria, derrota, empate }

// O Flutter começa a execução do aplicativo por esta função.
void main() {
  runApp(const AplicativoBlackjack());
}

class AplicativoBlackjack extends StatelessWidget {
  const AplicativoBlackjack({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Blackjack inicial',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.amber,
        scaffoldBackgroundColor: const Color(0xFF103B2C),
      ),
      home: const TelaJogo(),
    );
  }
}

// StatefulWidget permite que a tela mude quando as cartas forem compradas.
class TelaJogo extends StatefulWidget {
  const TelaJogo({super.key, this.servico});

  // Nos testes, podemos passar um serviço com respostas simuladas.
  final ServicoBaralho? servico;

  @override
  State<TelaJogo> createState() => _EstadoTelaJogo();
}

class _EstadoTelaJogo extends State<TelaJogo> {
  late final ServicoBaralho servico;
  List<Carta> cartasJogador = [];
  List<Carta> cartasBanca = [];
  bool mostrarMenu = true;
  bool carregando = false;
  bool rodadaTerminada = true;
  bool revelarBanca = false;
  String mensagem = 'Toque em Iniciar jogo para distribuir as cartas.';
  int vitorias = 0;
  int derrotas = 0;
  int empates = 0;

  @override
  void initState() {
    // Executa uma vez ao criar esta tela e prepara o serviço usado pela mesa.
    super.initState();
    servico = widget.servico ?? ServicoBaralho();
  }

  Future<void> abrirMesa() async {
    if (carregando) return;
    // O menu e a mesa usam o mesmo State, então as mãos não são perdidas.
    setState(() => mostrarMenu = false);
    if (cartasJogador.isEmpty) await iniciarRodada();
  }

  void voltarAoMenu() {
    if (carregando) return;
    setState(() => mostrarMenu = true);
  }

  void abrirRegras() {
    // Abre outra tela. O botão de voltar retorna à mesma partida.
    Navigator.push(
      context,
      MaterialPageRoute<void>(builder: (context) => const TelaRegras()),
    );
  }

  // Serve para iniciar o jogo e também para começar outra rodada.
  Future<void> iniciarRodada() async {
    if (carregando || !rodadaTerminada) return;
    setState(() {
      carregando = true;
      mensagem = 'Preparando as cartas...';
    });

    try {
      // Reutilizamos o baralho. O corte de 25% renova os 6 baralhos.
      if (servico.idBaralho.isEmpty || servico.cartasRestantes <= 78) {
        await servico.criarBaralho();
      }
      final cartas = await servico.comprarCartas(4);
      if (!mounted) return; // A tela pode ter sido fechada durante a espera.

      setState(() {
        // Distribuição alternada: jogador, banca, jogador, banca.
        cartasJogador = [cartas[0], cartas[2]];
        cartasBanca = [cartas[1], cartas[3]];
        rodadaTerminada = false;
        revelarBanca = false;
        mensagem = 'Sua vez: pedir uma carta ou parar?';
      });

      // Blackjack é 21 com DUAS cartas. As duas mãos precisam ser conferidas.
      final blackjackJogador = temBlackjack(cartasJogador);
      final blackjackBanca = temBlackjack(cartasBanca);
      if (blackjackJogador && blackjackBanca) {
        terminarRodada(
          'Empate! Os dois fizeram Blackjack.',
          ResultadoRodada.empate,
        );
      } else if (blackjackJogador) {
        terminarRodada('Blackjack! Você venceu.', ResultadoRodada.vitoria);
      } else if (blackjackBanca) {
        terminarRodada(
          'A banca fez Blackjack e venceu.',
          ResultadoRodada.derrota,
        );
      }
    } catch (erro) {
      tratarFalha();
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  Future<void> pedirCarta() async {
    if (carregando || rodadaTerminada) return;
    setState(() {
      carregando = true;
      mensagem = 'Pedindo uma carta...';
    });

    try {
      final cartas = await servico.comprarCartas(1);
      if (!mounted) return;
      setState(() => cartasJogador.add(cartas.first));

      final pontos = calcularPontos(cartasJogador);
      if (pontos > 21) {
        terminarRodada(
          'Você estourou 21. A banca venceu.',
          ResultadoRodada.derrota,
        );
      } else if (pontos == 21) {
        // Com 21, passamos automaticamente a vez para a banca.
        await jogarBanca();
      } else {
        setState(() => mensagem = 'Você tem $pontos pontos. Pedir ou parar?');
      }
    } catch (erro) {
      tratarFalha();
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  Future<void> parar() async {
    if (carregando || rodadaTerminada) return;
    setState(() => carregando = true);
    try {
      await jogarBanca();
    } catch (erro) {
      tratarFalha();
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  Future<void> jogarBanca() async {
    setState(() {
      revelarBanca = true;
      mensagem = 'A banca está jogando...';
    });

    // A banca compra abaixo de 17 e para em 17, inclusive com um Ás valendo 11.
    // "Parar" é uma regra local: a API só é chamada se faltarem cartas.
    while (calcularPontos(cartasBanca) < 17) {
      final cartas = await servico.comprarCartas(1);
      if (!mounted) return;
      setState(() => cartasBanca.add(cartas.first));
    }

    final pontosJogador = calcularPontos(cartasJogador);
    final pontosBanca = calcularPontos(cartasBanca);
    if (pontosBanca > 21 || pontosJogador > pontosBanca) {
      terminarRodada('Você venceu!', ResultadoRodada.vitoria);
    } else if (pontosJogador == pontosBanca) {
      terminarRodada('Empate!', ResultadoRodada.empate);
    } else {
      terminarRodada('A banca venceu.', ResultadoRodada.derrota);
    }
  }

  void terminarRodada(String texto, ResultadoRodada resultado) {
    // A mesma rodada só pode acrescentar um resultado ao placar.
    if (rodadaTerminada) return;
    setState(() {
      rodadaTerminada = true;
      revelarBanca = true;
      mensagem = texto;
      switch (resultado) {
        case ResultadoRodada.vitoria:
          vitorias++;
          break;
        case ResultadoRodada.derrota:
          derrotas++;
          break;
        case ResultadoRodada.empate:
          empates++;
          break;
      }
    });
  }

  void tratarFalha() {
    // Mesmo uma chamada GET de compra retira cartas do baralho remoto.
    // Se ela falhar, não sabemos se a carta já saiu: começamos uma nova mesa.
    servico.idBaralho = '';
    servico.cartasRestantes = 0;
    if (!mounted) return;
    // Falha de internet não é vitória nem derrota: o placar fica igual.
    setState(() {
      rodadaTerminada = true;
      revelarBanca = true;
      mensagem =
          'Não foi possível concluir. Confira a internet e reinicie o jogo.';
    });
  }

  @override
  void dispose() {
    servico.fechar();
    super.dispose();
  }

  Widget mostrarCarta(Carta carta) {
    // A carta local também permite estudar e testar sem baixar imagens.
    final cartaLocal = Card(
      color: Colors.white,
      child: Center(
        child: Text(
          '${carta.valorCurto}\n${carta.simboloNaipe}',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black, fontSize: 22),
        ),
      ),
    );
    return SizedBox(
      width: 80,
      height: 112,
      child: carta.imagem.isEmpty
          ? cartaLocal
          : Image.network(
              carta.imagem,
              fit: BoxFit.contain,
              errorBuilder: (context, erro, pilha) => cartaLocal,
            ),
    );
  }

  // Esta função monta uma mão. Wrap quebra a linha se houver muitas cartas.
  Widget mostrarMao(String titulo, List<Carta> cartas, bool esconderSegunda) {
    final cartasVisiveis = esconderSegunda ? cartas.take(1).toList() : cartas;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$titulo · ${calcularPontos(cartasVisiveis)} pontos${esconderSegunda ? ' + ?' : ''}',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (int indice = 0; indice < cartas.length; indice++)
              if (esconderSegunda && indice == 1)
                const SizedBox(
                  width: 80,
                  height: 112,
                  child: Card(
                    child: Center(
                      child: Text('?', style: TextStyle(fontSize: 32)),
                    ),
                  ),
                )
              else
                // Se a imagem não carregar, ainda mostramos o valor e o naipe.
                mostrarCarta(cartas[indice]),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // null no onPressed deixa o botão desativado enquanto a API responde.
    final podeJogar = !carregando && !rodadaTerminada;
    return Scaffold(
      appBar: AppBar(
        title: Text(mostrarMenu ? 'Blackjack 21' : 'Mesa de jogo'),
        leading: mostrarMenu
            ? null
            : IconButton(
                tooltip: 'Voltar ao menu',
                onPressed: carregando ? null : voltarAoMenu,
                icon: const Icon(Icons.arrow_back),
              ),
        actions: [
          TextButton(
            onPressed: carregando ? null : abrirRegras,
            child: const Text('Regras'),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Vitórias: $vitorias · Derrotas: $derrotas · Empates: $empates',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  if (mostrarMenu) ...[
                    const Icon(Icons.style, size: 72, color: Colors.amber),
                    const SizedBox(height: 16),
                    const Text(
                      'Um jogador contra a banca',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 22),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Chegue perto de 21 sem ultrapassar.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    FilledButton(
                      onPressed: abrirMesa,
                      child: Text(
                        cartasJogador.isEmpty
                            ? 'Iniciar jogo'
                            : 'Continuar mesa',
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'O placar vale enquanto o aplicativo estiver aberto.',
                      textAlign: TextAlign.center,
                    ),
                  ] else ...[
                    Text(
                      '6 baralhos · ${servico.cartasRestantes} cartas restantes',
                    ),
                    const SizedBox(height: 24),
                    mostrarMao(
                      'Banca',
                      cartasBanca,
                      !revelarBanca && cartasBanca.isNotEmpty,
                    ),
                    const SizedBox(height: 28),
                    Text(
                      mensagem,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 18),
                    ),
                    if (carregando) ...[
                      const SizedBox(height: 12),
                      const LinearProgressIndicator(),
                    ],
                    const SizedBox(height: 28),
                    mostrarMao('Jogador', cartasJogador, false),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: podeJogar ? pedirCarta : null,
                            child: const Text('Pedir carta'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: podeJogar ? parar : null,
                            child: const Text('Parar'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: !carregando && rodadaTerminada
                          ? iniciarRodada
                          : null,
                      child: Text(
                        servico.idBaralho.isEmpty
                            ? 'Iniciar jogo'
                            : 'Nova rodada',
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Objetivo: chegar perto de 21 sem ultrapassar.\nÁs vale 1 ou 11. J, Q e K valem 10.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
