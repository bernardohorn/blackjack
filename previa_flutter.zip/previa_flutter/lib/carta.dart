// Uma classe reúne as informações que pertencem a uma carta.
class Carta {
  final String valor;
  final String naipe;
  final String imagem;

  const Carta({required this.valor, required this.naipe, required this.imagem});

  // As chaves em inglês são definidas pela API e precisam manter esses nomes.
  factory Carta.doJson(Map<String, dynamic> dados) {
    final valor = dados['value'];
    final naipe = dados['suit'];
    const valores = [
      'ACE',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '10',
      'JACK',
      'QUEEN',
      'KING',
    ];
    const naipes = ['SPADES', 'HEARTS', 'DIAMONDS', 'CLUBS'];
    if (valor is! String ||
        !valores.contains(valor) ||
        naipe is! String ||
        !naipes.contains(naipe)) {
      throw const FormatException('A API devolveu uma carta inválida.');
    }
    return Carta(
      valor: valor,
      naipe: naipe,
      imagem: dados['image'] is String ? dados['image'] : '',
    );
  }

  // As letras impressas nas cartas evitam os nomes ingleses da API na tela.
  String get valorCurto {
    if (valor == 'ACE') return 'A';
    if (valor == 'JACK') return 'J';
    if (valor == 'QUEEN') return 'Q';
    if (valor == 'KING') return 'K';
    return valor;
  }

  String get simboloNaipe {
    if (naipe == 'SPADES') return '♠';
    if (naipe == 'HEARTS') return '♥';
    if (naipe == 'DIAMONDS') return '♦';
    return '♣';
  }
}

// A API fornece cartas. O aplicativo é responsável por calcular os pontos.
int calcularPontos(List<Carta> cartas) {
  int total = 0;
  int quantidadeAses = 0;

  for (final carta in cartas) {
    if (carta.valor == 'ACE') {
      total += 11;
      quantidadeAses++;
    } else if (['JACK', 'QUEEN', 'KING'].contains(carta.valor)) {
      total += 10;
    } else {
      total += int.parse(carta.valor);
    }
  }

  // Cada redução transforma um Ás de 11 em 1: a diferença é 10 pontos.
  while (total > 21 && quantidadeAses > 0) {
    total -= 10;
    quantidadeAses--;
  }
  return total;
}

bool temBlackjack(List<Carta> cartas) {
  return cartas.length == 2 && calcularPontos(cartas) == 21;
}
