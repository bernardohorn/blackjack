import 'dart:convert';
import 'package:http/http.dart' as http;

import 'carta.dart';

// Somente este arquivo conversa com a Deck of Cards API.
class ServicoBaralho {
  final http.Client _cliente;
  String idBaralho = '';
  int cartasRestantes = 0;

  // O cliente opcional permite testar a API usando respostas simuladas.
  ServicoBaralho({http.Client? cliente}) : _cliente = cliente ?? http.Client();

  Future<void> criarBaralho() async {
    // Endpoint 1: cria e embaralha seis baralhos, com 312 cartas no total.
    final dados = await consultar('/api/deck/new/shuffle/', {
      'deck_count': '6',
    });
    final identificador = dados['deck_id'];
    if (identificador is! String ||
        identificador.trim().isEmpty ||
        dados['remaining'] is! int ||
        dados['remaining'] != 312) {
      throw const FormatException('Não foi possível criar o baralho.');
    }
    idBaralho = identificador;
    cartasRestantes = dados['remaining'];
  }

  Future<List<Carta>> comprarCartas(int quantidade) async {
    if (idBaralho.isEmpty || quantidade < 1 || quantidade > cartasRestantes) {
      throw const FormatException(
        'Não há cartas suficientes para essa compra.',
      );
    }

    // Endpoint 2: retira cartas do baralho identificado por idBaralho.
    // Usamos count=4 na distribuição e count=1 nas compras seguintes.
    final dados = await consultar('/api/deck/$idBaralho/draw/', {
      'count': '$quantidade',
    });
    final cartasJson = dados['cards'];
    final restantes = dados['remaining'];
    if (dados['deck_id'] != idBaralho ||
        cartasJson is! List ||
        cartasJson.length != quantidade ||
        restantes is! int ||
        restantes < 0 ||
        restantes != cartasRestantes - quantidade) {
      throw const FormatException('A compra veio incompleta ou inválida.');
    }

    final cartas = <Carta>[];
    for (final cartaJson in cartasJson) {
      if (cartaJson is! Map<String, dynamic>) {
        throw const FormatException('A API devolveu uma carta inválida.');
      }
      cartas.add(Carta.doJson(cartaJson));
    }

    // Atualizamos a contagem apenas depois de conferir TODAS as cartas.
    cartasRestantes = restantes;
    return cartas;
  }

  // Future significa que a resposta chegará depois. await espera por ela.
  Future<Map<String, dynamic>> consultar(
    String caminho,
    Map<String, String> parametros,
  ) async {
    final endereco = Uri.https('deckofcardsapi.com', caminho, parametros);
    final resposta = await _cliente
        .get(endereco)
        .timeout(const Duration(seconds: 15));
    if (resposta.statusCode < 200 || resposta.statusCode >= 300) {
      throw Exception('A API não respondeu com sucesso.');
    }

    // JSON é o formato de texto da resposta; jsonDecode transforma em dados.
    final dados = jsonDecode(resposta.body);
    if (dados is! Map<String, dynamic> || dados['success'] != true) {
      throw const FormatException('A API informou uma falha.');
    }
    return dados;
  }

  void fechar() {
    _cliente.close();
  }
}
