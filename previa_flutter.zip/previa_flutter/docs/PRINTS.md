# Prints do aplicativo

As imagens abaixo mostram o menu, a tela de regras e os diferentes estados da mesa. Foram geradas com os widgets reais do aplicativo Flutter, usando respostas da API simuladas para reproduzir os resultados. Não são imagens do Figma.

Cada PNG mede **780 × 1920 pixels**, correspondente a uma tela de **390 × 960** com captura em escala 2×. As oito imagens foram conferidas visualmente: textos, botões, placar, ícones e naipes estão visíveis.

As cartas aparecem pelo desenho local de valor e naipe, pois as respostas simuladas têm o endereço da imagem vazio. O carregamento das imagens da API real foi verificado separadamente no navegador, conforme o [README](../README.md).

## Visão geral

[Abrir a visão geral das capturas](prints/visao-geral.png).

## Menu inicial

Botões para iniciar a partida e consultar as regras, com o placar zerado.

![Menu inicial](prints/01-menu.png)

## Regras do jogo

Explicação do objetivo, pontuação das cartas e comportamento da banca.

![Regras do jogo](prints/02-regras.png)

## Mesa em andamento

Jogador com 16 pontos. A banca mostra um Ás e mantém a segunda carta escondida. Os botões **Pedir carta** e **Parar** estão disponíveis.

![Mesa em andamento](prints/03-mesa.png)

## Vitória

Jogador com 18 pontos contra 17 da banca. O placar registra uma vitória.

![Vitória](prints/04-vitoria.png)

## Derrota

Jogador chega a 25 pontos ao pedir uma carta e estoura 21. O placar registra uma derrota.

![Derrota](prints/05-derrota.png)

## Empate

Jogador e banca terminam com 18 pontos. O placar registra um empate.

![Empate](prints/06-empate.png)

## Blackjack

Jogador recebe Ás e K: 21 com duas cartas. A rodada termina com vitória e a mão da banca é revelada.

![Blackjack](prints/07-blackjack.png)

## Falha de comunicação

Uma compra recebe erro simulado. O aplicativo mostra a mensagem para conferir a internet e reiniciar, libera **Iniciar jogo** e mantém o placar zerado.

![Falha de comunicação](prints/08-falha.png)

## Como gerar novamente

Na pasta do projeto, execute:

```powershell
flutter pub get
flutter test test/gerar_prints_test.dart --dart-define=GERAR_PRINTS=true
```

Os oito testes de captura ficam pulados em `flutter test` sem essa opção. A ferramenta de geração está em [test/gerar_prints_test.dart](../test/gerar_prints_test.dart) e não faz parte do código executado pelo aplicativo.

Para os textos e ícones, a ferramenta carrega Roboto e MaterialIcons do SDK do Flutter. Para os naipes, usa uma fonte de símbolos instalada no sistema: Segoe UI Symbol no Windows, ou DejaVu/Noto no Linux. As fontes do sistema não são distribuídas com o projeto.
